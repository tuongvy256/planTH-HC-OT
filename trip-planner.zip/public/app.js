
function showTab(id){
 document.querySelectorAll('section').forEach(x=>x.style.display='none');
 document.getElementById(id).style.display='block';
}
async function load(){
 const r=await fetch('/api/data');
 const d=await r.json();
 document.getElementById('timeline').innerHTML=d.timeline.map(t=>`<div class="card"><b>${t.location}</b><br>${t.time_slot||''}<br>${t.content||''}</div>`).join('');
 document.getElementById('checklist').innerHTML=d.checklist.map(i=>`<div class="card">${i.is_checked?'✅':'⬜'} ${i.item_name}</div>`).join('');
 const est=d.timeline.reduce((a,b)=>a+(+b.cost_est||0),0);
 const real=d.timeline.reduce((a,b)=>a+(+b.cost_real||0),0);
 document.getElementById('cost').innerHTML=`<div class="card">Dự kiến: ${est}<br>Thực tế: ${real}<br>Mỗi người: ${real/2}</div>`;
}
load();
